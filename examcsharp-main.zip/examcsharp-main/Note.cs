﻿namespace tp_examc_
{
    public class Note
    {
        public int Id { get; set; }
        public int EtudiantId { get; set; }
        public int ModuleId { get; set; }
        public double Valeur { get; set; }
    }
}
