﻿namespace tp_examc_
{
    public class Enseignant : Utilisateur
    {
        public override string Role => "Enseignant";
    }
}
