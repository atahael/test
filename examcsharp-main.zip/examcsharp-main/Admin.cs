﻿namespace tp_examc_
{
    public class Admin : Utilisateur
    {
        public override string Role => "Admin";
    }
}
