﻿namespace tp_examc_
{
    public class Etudiant : Utilisateur
    {
        public override string Role => "Etudiant";
    }
}
