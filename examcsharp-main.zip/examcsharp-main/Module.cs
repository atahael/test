﻿namespace tp_examc_
{
    public class Module
    {
        public int Id { get; set; }
        public string Nom { get; set; } = "";
    }
}
